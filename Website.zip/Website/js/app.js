const overlay = document.querySelector(".overlay");
const modal = document.querySelector(".inscribete__modal");
const btnClose = document.querySelector(".close");
const modalOpener = document.querySelector(".modalOpener");

modalOpener.addEventListener("click", (e) => {
  overlay.classList.remove("hide");
  modal.classList.remove("hide");
});

btnClose.addEventListener("click", () => {
  overlay.classList.add("hide");
  modal.classList.add("hide");
});
